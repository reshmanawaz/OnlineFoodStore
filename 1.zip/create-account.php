<html>
<body>

<h2>Create new Account</h2>

<form action="/create-account.php">
  <p align="center">
    <label for="fname">First name:</label>
    <input type="text" id="fname" name="fname"
  </p>
  <p align="center">
    <label for="lname">Last name:</label>
    <input type="text" id="lname" name="lname"
  </p>
  <p align="center">
    <label for="user">Username:</label>
    <input type="text" id="user" name="user"
  </p>
  <p align="center">
    <label for="pw">Password:</label>
    <input type="text" id="password" name="password"
  </p>
  <br>
  <br>
  <input type="submit" value="Submit">
</form>



</body>
</html>
